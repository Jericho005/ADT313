import React, { createContext, useState } from 'react';
import data from './problem7_mock_data.json'; 


export const Problem7Context = createContext();


export const Problem7Provider = ({ children }) => {
  const [selectedData, setSelectedData] = useState(null); 

  return (
    <Problem7Context.Provider value={{ data, selectedData, setSelectedData }}>
      {children}
    </Problem7Context.Provider>
  );
};
