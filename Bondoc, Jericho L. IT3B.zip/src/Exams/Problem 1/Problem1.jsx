import React from 'react';


const Problem1 = ({ studentName, course, section }) => {
  return (
    <div className="student-info">
      <h2>Student Information</h2>
      <p><strong>Name: Jericho Bondoc</strong> </p>
      <p><strong>Course: Information Technology</strong> </p>
      <p><strong>Section: IT3B</strong> </p>
    </div>
  );
};

export default Problem1;
