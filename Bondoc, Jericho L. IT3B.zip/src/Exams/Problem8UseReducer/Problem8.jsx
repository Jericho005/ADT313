import { useReducer, useState } from "react";
import data from './problem8mock_data.json';


const foodReducer = (state, action) => {
  switch (action.type) {
    case 'CREATE':
      return [...state, action.payload];
    case 'UPDATE':
      return state.map(food =>
        food.id === action.payload.id ? action.payload : food
      );
    case 'DELETE':
      return state.filter(food => food.id !== action.payload);
    case 'SELECT':
      return state;
    case 'CLEAR':
      return state;
    default:
      return state;
  }
};

export default function Problem8() {
  const [foods, dispatch] = useReducer(foodReducer, data);
  const [selectedFood, setSelectedFood] = useState(null);


  const handleSave = () => {
    if (selectedFood && selectedFood.id) {
      dispatch({ type: 'UPDATE', payload: selectedFood });
    } else {
      const newFood = { ...selectedFood, id: Date.now() }; 
      dispatch({ type: 'CREATE', payload: newFood });
    }
    setSelectedFood(null); 
  };


  const handleEdit = (food) => {
    setSelectedFood(food);
  };


  const handleDelete = (foodId) => {
    dispatch({ type: 'DELETE', payload: foodId });
  };


  const handleClear = () => {
    setSelectedFood(null);
  };

  return (
    <>
      <div>
        <div style={{ display: 'block' }}>
          <label>Food Name:</label>
          <input
            type="text"
            value={selectedFood ? selectedFood.food_name : ""}
            onChange={(e) =>
              setSelectedFood((prev) => ({ ...prev, food_name: e.target.value }))
            }
          />
        </div>
        <div style={{ display: 'block' }}>
          <label>Price:</label>
          <input
            type="number"
            value={selectedFood ? selectedFood.price : ""}
            onChange={(e) =>
              setSelectedFood((prev) => ({ ...prev, price: e.target.value }))
            }
          />
        </div>
        <div style={{ display: 'block' }}>
          <label>Expiration Date:</label>
          <input
            type="text"
            value={selectedFood ? selectedFood.expiration_date : ""}
            onChange={(e) =>
              setSelectedFood((prev) => ({ ...prev, expiration_date: e.target.value }))
            }
          />
        </div>
        <div style={{ display: 'block' }}>
          <label>Calories:</label>
          <input
            type="number"
            value={selectedFood ? selectedFood.calories : ""}
            onChange={(e) =>
              setSelectedFood((prev) => ({ ...prev, calories: e.target.value }))
            }
          />
        </div>

        <button type="button" onClick={handleSave}>
          Save
        </button>
        <button type="button" onClick={handleClear}>
          Clear
        </button>
      </div>

      <div className="table-container">
        <table style={{ width: '100%' }}>
          <thead>
            <tr>
              <th>Food Name</th>
              <th>Price</th>
              <th>Expiration Date</th>
              <th>Calories</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody style={{ textAlign: 'center' }}>
            {foods.map((food) => (
              <tr key={food.id}>
                <td>{food.food_name}</td>
                <td>{food.price}</td>
                <td>{food.expiration_date}</td>
                <td>{food.calories}</td>
                <td>
                  <button type="button" onClick={() => handleEdit(food)}>
                    Edit
                  </button>
                  <button type="button" onClick={() => handleDelete(food.id)}>
                    Delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  );
}
