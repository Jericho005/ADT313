import React from 'react';

export default function Loading() {
  return (
    <div
      style={{
        background: 'darkblue',
        height: '100vh',
        width: '100%',
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        color: 'white',
        fontSize: '24px',
      }}
    >
      <h2>Page is loading...</h2>
    </div>
  );
}
