import { useEffect, useState, useRef } from 'react';
import Loading from './Problem5Components/Loading';

export default function Problem5() {
  const [isLoading, setIsLoading] = useState(true); 
  const [isTyping, setIsTyping] = useState(false);  
  const [inputValue, setInputValue] = useState('');  
  const idleTimeoutRef = useRef(null); 


  useEffect(() => {
    const loadingTimeout = setTimeout(() => {
      setIsLoading(false); 
    }, 4000);

    return () => clearTimeout(loadingTimeout); 
  }, []);

  
  useEffect(() => {
    
    if (inputValue) {
      setIsTyping(true);
      setIsLoading(false); 
    } else {
      setIsTyping(false); 
    }

    
    if (idleTimeoutRef.current) {
      clearTimeout(idleTimeoutRef.current);
    }

    
    idleTimeoutRef.current = setTimeout(() => {
      setIsLoading(true); 
      setIsTyping(false);  
    }, 2000); 

    return () => {
      if (idleTimeoutRef.current) {
        clearTimeout(idleTimeoutRef.current);
      }
    };
  }, [inputValue]); 

  return (
    <>
      {isLoading ? (
        <Loading />
      ) : (
        <div style={{ display: 'block' }}>
          Input: 
          <input
            type="text"
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)} 
          />
          <p>{isTyping ? 'User is typing...' : 'User is idle...'}</p>
        </div>
      )}
    </>
  );
}